let multi=1;
for(let i = 1;i<=10;i+=1){
    multi*=i;
}
console.log(multi);