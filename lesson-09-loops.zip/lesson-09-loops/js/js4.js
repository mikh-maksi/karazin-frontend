sum = 0;
i=0;
while(sum<=100){
    sum+=i;
    i++;
}
console.log(i-1);