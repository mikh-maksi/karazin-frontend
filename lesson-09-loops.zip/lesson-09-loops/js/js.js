let sum = 0;
for (let i = 1;i<=25;i++){
    sum += i;
}
alert(sum);